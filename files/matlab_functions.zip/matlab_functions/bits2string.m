function string = bits2string(bits)
% converts the bits vector to a MATLAB string  
% (c) 2019 studer@cornell.edu
%
% usage:
%   string2bits(filename)
%   string : string to be converted
%   bits   : bits that can be transmitted (adds a leading 1)

string = char(bin2dec(char(reshape(bits(2:end),[],8) + '0')))';


end
