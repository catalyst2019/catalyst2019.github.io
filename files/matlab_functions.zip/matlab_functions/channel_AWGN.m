function [output,noise] = channel_AWGN(input)
% Models an AWGN channel 
% (c) 2019 studer@cornell.edu
%
% usage:
%   output = channel_AWGN(input)
%   input  : input samples
%   output : output of AWGN channel

SNR = mean(input.^2)*0.5^2/(0.1)^2;
SNRdB = 10*log10(SNR);

fprintf('Transmitting signal over AWGN channel with %2.2fdB SNR\n',SNRdB);
noise = 0.1*randn(size(input));
output = min(max(0.5*input + noise ,-1),+1);

end


