function save_audio(filename,y,FS)
% save audio signal to file
% (c) 2019 studer@cornell.edu
%
% usage:
%   save_audio(filename,y,FS)
%   filename : name of file (include path information)
%   y        : signal to be saved
%   FS       : sampling rate

fprintf('Saving %s...\n',filename)
audiowrite(filename,y,FS);

end


