function y = record_audio(sec,FS,InpID)
% record audio signal
% (c) 2019 studer@cornell.edu
%
% usage:
%   y = play_audio(FS,ID)
%   sec    : seconds of recording 
%   FS     : sampling rate 
%   InpID  : input device InpID

fprintf('Recording audio signal for %i seconds from device InpID=%i...\n',sec,InpID)
recObj = audiorecorder(FS,16,1,InpID);
recordblocking(recObj,sec);
y = getaudiodata(recObj);
fprintf('Recording stopped.')

end

