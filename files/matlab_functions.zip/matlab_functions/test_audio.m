function out = test_audio(OutID)
% this function tests the audio output of your soundcard
% (c) 2019 studer@cornell.edu

% usage:
%   test_audio(OutID)
%   OutID : output device ID

% define file name of test signal
filename = 'examples/speech-female.wav';

% load audio file 
[y,FS] = load_audio(filename);

% play test signal
out = play_audio(y,FS,OutID);

end
