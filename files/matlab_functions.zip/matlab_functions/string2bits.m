function bits = string2bits(string)
% converts a MATLAB string to a bit vector
% (c) 2019 studer@cornell.edu
%
% usage:
%   string2bits(filename)
%   string : string to be converted
%   bits   : bits that can be transmitted (adds a leading 1)

string_binary = dec2bin(string', 8) - '0';
bits = [1;string_binary(:)]';

end
