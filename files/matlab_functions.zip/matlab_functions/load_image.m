function [bits] = load_image(filename)
% load a tiff image and convert it into a bit stream that we can transmit
% (c) 2019 studer@cornell.edu
%
% usage:
%   load_image(filename)
%   filename : name of file (include path information)
%   bits     : binary representation of image 

% read image 
img = double(imread(filename));

% show original image
h11 = figure(11);
imshow(img/255);
%print(h11,'-loose','-depsc','image_gray.eps');
%imwrite(uint8(img),'image_gray.png')

% apply floyd-steinberg dithering
a = img;
s = size(img);
for i = 1:s(1)
       for j = 1:s(2)
           if(a(i,j) < 127 )
               b(i,j) = 0;
           else 
               b(i,j) = 255;
           end
           qerror = a(i,j) - b(i,j);
       if(j < s(2))
           a(i,j+1) =  ((7/16 *qerror)+a(i,j+1)); 
       end
       if(i<s(1) && j > 1)
           a(i+1,j-1) = a(i+1,j-1) + (3/16 *qerror);
           a(i+1,j) = a(i+1,j) + (5/16 *qerror);
       end
       if(j<s(2) && i<s(1))
           a(i+1,j+1) = a(i+1,j+1) + (1/16 *qerror);
       end
       end
end
bits = double(a>=127);

% show dithered image
h12 = figure(12);
imshow(bits);
%print(h12,'-loose','-depsc','image_bw.eps');
%imwrite(bits*255,'image_bw.png')

bits = [1;bits(:)]';
end