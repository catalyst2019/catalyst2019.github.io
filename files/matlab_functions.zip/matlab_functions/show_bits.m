function  show_bits(bits)
% displays bit stream as image
% (c) 2019 studer@cornell.edu
%
% usage:
%   show_bits(filename)
%   bits   : binary representation of image

crop_bits = bits(2:end); % remove leading 1

len = length(crop_bits);
side = round(sqrt(len));

% check if image is square
if side*side==len
    % display image
    h13=figure(13);
    imshow(reshape(crop_bits,side,side))
    %print(h13,'-loose','-depsc','image_rec.eps')   
    %imwrite(uint8(reshape(crop_bits,side,side)*255),'image_rec.png')
else
    error('Image is not square; cannot display.')
end

end