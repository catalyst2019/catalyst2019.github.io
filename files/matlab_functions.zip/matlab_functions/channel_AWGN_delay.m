function [output,noise] = channel_AWGN_delay(input)
% Models an AWGN channel with a random time delay
% (c) 2019 studer@cornell.edu
%
% usage:
%   output = channel_AWGN_delay(input)
%   input  : input samples
%   output : output of AWGN channel

SNR = mean(input.^2)*0.5^2/(0.1)^2;
SNRdB = 10*log10(SNR);

% generate random pre and post delay
pre_delay = 100 + round(3000*rand(1));
post_delay = 100 + round(3000*rand(1));
input = [ zeros(pre_delay,1) ; input(:) ; zeros(post_delay,1) ]';

fprintf('Transmitting signal over AWGN channel with %2.1fdB SNR and a random delay\n',SNRdB);
noise = 0.1*randn(size(input));
output = min(max(0.5*input + noise ,-1),+1);

end


